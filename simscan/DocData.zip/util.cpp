
#include "StdAfx.h"
#include <dbSubD.h>

#include "util.h"

#define TSNOPT L"General"

//-----------------------------------------------------------------------------
Acad::ErrorStatus util::AddEntityToModelSpace(AcDbObjectId& objId, AcDbEntity* pEntity,
	Adesk::Boolean isClose, AcDbDatabase* pDb)
{
	Acad::ErrorStatus     es = Acad::eOk;
	AcDbBlockTable* pBlockTable;
	AcDbBlockTableRecord* pSpaceRecord;

	if (pDb == NULL) pDb = acdbCurDwg();
	pDb->getSymbolTable(pBlockTable, AcDb::kForRead);

	pBlockTable->getAt(ACDB_MODEL_SPACE, pSpaceRecord, AcDb::kForWrite);

	es = pSpaceRecord->appendAcDbEntity(objId, pEntity);
	pSpaceRecord->close();
	pBlockTable->close();

	if (es == Acad::eOk)
	{
		if (isClose == Adesk::kTrue) pEntity->close();
	}
	else delete pEntity;
	return es;
}

//=============================================================================
// ������� ����������� ������ ���� ��� ���������� ���������
// entId   - (��������) ������������� ���������
int util::GetStatusLayerEntity(const AcDbObjectId& entId)
{
	AcDbEntity* pEntity = NULL;
	if (acdbOpenObject(pEntity, entId, AcDb::kForRead) == Acad::eOk)
	{
		int result = util::GetStatusLayerEntity(pEntity);
		pEntity->close();
		return result;
	}
	return EL_ERROR;
}

int util::GetStatusLayerEntity(AcDbEntity* pEntity)
{
	AcDbLayerTableRecord* pLayer = NULL;
	if (pEntity && (acdbOpenObject(pLayer, pEntity->layerId(), AcDb::kForRead) == Acad::eOk))
	{
		int result = 0;
		if (pLayer->isLocked())	result |= EL_IS_LOCKED;
		if (pLayer->isOff())		result |= EL_IS_OFF;
		if (pLayer->isFrozen())	result |= EL_IS_FROZEN;
		pLayer->close();
		return result;
	}
	return EL_ERROR;
}

int util::GetMeshFromDb(AcDbObjectIdArray& ids, AcDbDatabase* pDb)
{
	ids.setLogicalLength(0);
	if (pDb == nullptr) pDb = acdbCurDwg();

	AcDbBlockTable* pBlockTable;
	pDb->getSymbolTable(pBlockTable, AcDb::kForRead);
	AcDbBlockTableRecord* pSpaceRecord;
	pBlockTable->getAt(ACDB_MODEL_SPACE, pSpaceRecord, AcDb::kForRead);
	pBlockTable->close();
	AcDbBlockTableRecordIterator* pIterator = nullptr;
	Acad::ErrorStatus es = pSpaceRecord->newIterator(pIterator);
	pSpaceRecord->close();
	if (es != Acad::eOk) return 0;//����� ������� ���������

	AcDbEntity* pEntity; 
	for (pIterator->start(); !pIterator->done(); pIterator->step()) {
		if (pIterator->getEntity(pEntity, AcDb::kForRead) == Acad::eOk)
		{
			if (pEntity->isKindOf(AcDbSubDMesh::desc()) &&
				(util::GetStatusLayerEntity(pEntity) <= EL_IS_OFF)) ids.append(pEntity->objectId());
			pEntity->close();
		}
	}
	delete pIterator;
	return ids.length();
}

AcGeCurve3d* util::convertDbCurveToGeCurve3d(AcDbCurve* pDbCurve)
{
	AcGeCurve3d* pGeCurve = NULL;
	// for Line: is very simple;
	if (pDbCurve->isKindOf(AcDbLine::desc()))
	{
		AcDbLine* pL = AcDbLine::cast(pDbCurve);
		AcGeLineSeg3d* pGL = new AcGeLineSeg3d;
		pGL->set(pL->startPoint(), pL->endPoint());
		pGeCurve = (AcGeCurve3d*)pGL;
	}
	// for Arc;
	else if (pDbCurve->isKindOf(AcDbArc::desc()))
	{
		AcDbArc* pArc = AcDbArc::cast(pDbCurve);
		double ans, ane;
		ans = pArc->startAngle();
		ane = pArc->endAngle();
		AcGeCircArc3d* pGArc = new AcGeCircArc3d;
		pGArc->setCenter(pArc->center());
		pGArc->setRadius(pArc->radius());
		pGArc->setAngles(ans, ane);
		pGeCurve = (AcGeCurve3d*)pGArc;
	}
	// for Circle;
	else if (pDbCurve->isKindOf(AcDbCircle::desc()))
	{
		AcDbCircle* pCir = AcDbCircle::cast(pDbCurve);
		AcGeCircArc3d* pGCir = new AcGeCircArc3d;
		pGCir->setCenter(pCir->center());
		pGCir->setRadius(pCir->radius());
		pGeCurve = (AcGeCurve3d*)pGCir;
	}
	//for Ellipse
	else if (pDbCurve->isKindOf(AcDbEllipse::desc()))
	{
		AcDbEllipse* pEli = AcDbEllipse::cast(pDbCurve);
		AcGePoint3d center = pEli->center();
		AcGeVector3d pv1 = pEli->majorAxis();
		double majorRadius = sqrt(pv1.x * pv1.x + pv1.y * pv1.y + pv1.z * pv1.z);
		double param1, param2;
		pEli->getStartParam(param1);
		pEli->getEndParam(param2);

		AcGeEllipArc3d* pGEli = new AcGeEllipArc3d;
		pGEli->setCenter(center);
		pGEli->setAxes(pv1, pEli->minorAxis());
		pGEli->setMajorRadius(majorRadius);
		pGEli->setMinorRadius(majorRadius * (pEli->radiusRatio()));
		pGEli->setAngles(param1, param2);
		pGeCurve = (AcGeCurve3d*)pGEli;
	}
	//for Spline
	else if (pDbCurve->isKindOf(AcDbSpline::desc()))
	{
		AcDbSpline* pSL = AcDbSpline::cast(pDbCurve);
		if (!pSL || pSL->isNull())	return NULL;

		int degree;
		Adesk::Boolean rational;
		Adesk::Boolean closed;
		Adesk::Boolean periodic;
		AcGePoint3dArray controlPoints;
		AcGeDoubleArray knots;
		AcGeDoubleArray weights;
		double controlPtTol;
		double knotTol;
		AcGeTol tol;
		Acad::ErrorStatus es;
		es = pSL->getNurbsData(degree, rational, closed, periodic, controlPoints, knots, weights, controlPtTol, knotTol);

		if (es != Acad::eOk) return NULL;

		if (rational == Adesk::kTrue)
		{
			AcGeNurbCurve3d* pNurb = new AcGeNurbCurve3d(degree, knots, controlPoints, weights, periodic);
			pGeCurve = (AcGeCurve3d*)pNurb;
		}
		else
		{
			AcGeNurbCurve3d* pNurb = new AcGeNurbCurve3d(degree, knots, controlPoints, periodic);
			pGeCurve = (AcGeCurve3d*)pNurb;
		}
	}
	// for Polyline
	else if (pDbCurve->isKindOf(AcDbPolyline::desc()))
	{
		AcDbPolyline* pPoly = AcDbPolyline::cast(pDbCurve);
		AcGeLineSeg3d line;
		AcGeCircArc3d arc;
		AcGeVoidPointerArray geCurves;
		int nSegs = pPoly->numVerts() - 1;
		if (pPoly->isClosed()) ++nSegs;
		for (int i = 0; i < nSegs; i++)
		{
			if (pPoly->segType(i) == AcDbPolyline::kLine)
			{
				pPoly->getLineSegAt(i, line);
				geCurves.append(new AcGeLineSeg3d(line));
			}
			else if (pPoly->segType(i) == AcDbPolyline::kArc)
			{
				pPoly->getArcSegAt(i, arc);
				geCurves.append(new AcGeCircArc3d(arc));
			}
		}
		if (geCurves.length() == 1)
		{
			pGeCurve = (AcGeCurve3d*)(geCurves[0]);
		}
		else
		{
			pGeCurve = new AcGeCompositeCurve3d(geCurves);
		}
	}
	// for Polyline 3d
	else if (pDbCurve->isKindOf(AcDb3dPolyline::desc()))
	{
		//int err = 0;
		AcDb3dPolyline* pPoly3d = AcDb3dPolyline::cast(pDbCurve);
		AcGePoint3dArray arrayPnts;
		AcDb3dPolylineVertex* vrtx3;
		AcDbObjectIterator* iter = pPoly3d->vertexIterator();
		for (iter->start(); !iter->done(); iter->step())
		{
			Acad::ErrorStatus es = pPoly3d->openVertex(vrtx3, iter->objectId(), AcDb::kForRead);
			if (es == Acad::eOk)
			{
				arrayPnts.append(vrtx3->position());
				vrtx3->close();
			} //else err++;
		}
		delete iter;
		if (arrayPnts.length() < 2) return pGeCurve;

		//CString str;
		//str.Format(_T("��� AcDb3dPolyline pnt=%d\n err = %d\n"), arrayPnts.length(), err);
		//str += erstr;
		//AfxMessageBox(str);

		int nSegs;
		AcGeLineSeg3d* pLine;
		AcGeVoidPointerArray geCurves;
		if (pPoly3d->isClosed())
		{
			nSegs = arrayPnts.length();
			arrayPnts.append(arrayPnts.first());
		}
		else
		{
			nSegs = arrayPnts.length() - 1;
		}
		for (int i = 0; i < nSegs; i++)
		{
			pLine = new AcGeLineSeg3d;
			pLine->set(arrayPnts[i], arrayPnts[i + 1]);
			geCurves.append(pLine);
		}

		pGeCurve = (geCurves.length() == 1) ? (AcGeCurve3d*)(geCurves[0]) : new AcGeCompositeCurve3d(geCurves);
	}
	//else if (pDbCurve->isKindOf(AcDb2dPolyline::desc()))
	//{
	//}
	return pGeCurve;
}

void util::getProfile(LPTSTR buf, int ccMax)
{
	TCHAR dir[_MAX_DIR], drive[_MAX_DRIVE];
	_tsplitpath_s(acedGetAppName(), drive, _MAX_DRIVE, dir, _MAX_DIR, NULL, 0, NULL, 0);
	_tmakepath_s(buf, ccMax, drive, dir, L"simopt", L".inf");
}

double util::fromProfile(double def, LPCTSTR key, LPCTSTR app)
{
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);

	TCHAR buf[64], sdef[64];
	_stprintf_s(sdef, _countof(sdef), _T("%g"), def);
	if (GetPrivateProfileString(app ? app : TSNOPT, key, sdef, buf, _countof(buf), profFile) < 1)
		_tcscpy_s(buf, _countof(buf), sdef);
	return _tstof(buf);
}
int util::fromProfile(int def, LPCTSTR key, LPCTSTR app)
{
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);

	return (int)GetPrivateProfileInt(app ? app : TSNOPT, key, (INT)def, profFile);
}

__int64 util::fromProfile(__int64 def, LPCTSTR key, LPCTSTR app)
{
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);

	TCHAR buf[64], sdef[64];
	_stprintf_s(sdef, _countof(sdef), _T("%I64u"), def);
	if (GetPrivateProfileString(app ? app : TSNOPT, key, sdef, buf, _countof(buf), profFile) < 1)
		_tcscpy_s(buf, _countof(buf), sdef);

	return _tcstoui64(buf, NULL, 10);
}

int util::fromProfile(AcGeIntArray& arr, LPCTSTR key, LPCTSTR app)
{
	arr.setLogicalLength(0);

	TCHAR buff[2048];
	util::fromProfile((LPTSTR)buff, _countof(buff), _T(""), key, app);
	TCHAR* next_token = NULL, * token = _tcstok_s(buff, _T(","), &next_token);
	while (token != NULL)
	{
		arr.append(_tstoi(token));
		token = _tcstok_s(NULL, _T(","), &next_token);
	}
	return arr.length();
}

COLORREF util::fromProfileColor(COLORREF def, LPCTSTR key, LPCTSTR app)
{
	AcGeIntArray arr;
	int n = util::fromProfile(arr, key, app);
	if (n == 3) return RGB(arr[0], arr[1], arr[2]);
	return def;
}


int util::fromProfile(CListCtrl& lst, LPCTSTR key, LPCTSTR app)
{
	AcGeIntArray aw;
	CHeaderCtrl* pHeaderCtrl = lst.GetHeaderCtrl();
	int m = pHeaderCtrl->GetItemCount(), n = util::fromProfile(aw, key, app);
	if (n != m)
	{
		CRect rc; lst.GetClientRect(&rc);
		aw.setLogicalLength(m);
		aw.setAll((int)(rc.Width() / ((double)m)));
		return 0;
	}
	for (int i = 0; i < m; i++) lst.SetColumnWidth(i, aw[i]);
	return m;
}


LPCTSTR util::fromProfile(LPTSTR buf, int ccMax, LPCTSTR def, LPCTSTR key, LPCTSTR app)
{
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);

	if (GetPrivateProfileString(app ? app : TSNOPT, key, def, buf, ccMax, profFile) < 1) _tcscpy_s(buf, ccMax, def);
	return (LPCTSTR)buf;
}

BOOL util::toProfile(double val, LPCTSTR key, LPCTSTR app)
{
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);

	TCHAR buf[64];
	_stprintf_s(buf, _countof(buf), _T("%g"), val);
	return WritePrivateProfileString(app ? app : TSNOPT, key, buf, profFile);
}

BOOL util::toProfile(int val, LPCTSTR key, LPCTSTR app)
{
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);

	TCHAR buf[64];
	_stprintf_s(buf, _countof(buf), _T("%d"), val);
	return WritePrivateProfileString(app ? app : TSNOPT, key, buf, profFile);
}

BOOL util::toProfile(__int64 val, LPCTSTR key, LPCTSTR app)
{
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);

	TCHAR buf[64];
	_stprintf_s(buf, _countof(buf), _T("%I64u"), val);
	return WritePrivateProfileString(app ? app : TSNOPT, key, buf, profFile);
}


BOOL util::toProfile(LPCTSTR str, LPCTSTR key, LPCTSTR app)
{
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);

	return WritePrivateProfileString(app ? app : TSNOPT, key, str, profFile);
}

BOOL util::toProfile(AcGeIntArray& arr, LPCTSTR key, LPCTSTR app)
{
	TCHAR buff[2048]; buff[0] = _T('\0');
	int n = arr.length();
	for (int i = 0; i < n; i++)
	{
		TCHAR vol[32];
		_stprintf_s(vol, 32, _T("%d"), arr[i]);
		if (i) _tcscat_s(buff, _countof(buff), _T(","));
		_tcscat_s(buff, _countof(buff), vol);
	}
	TCHAR profFile[_MAX_PATH];
	util::getProfile(profFile, _MAX_PATH);
	return WritePrivateProfileString(app ? app : TSNOPT, key, buff, profFile);
}

BOOL util::toProfileColor(COLORREF rgb, LPCTSTR key, LPCTSTR app)
{
	AcGeIntArray arr;
	arr.setLogicalLength(3);
	arr[0] = GetRValue(rgb);
	arr[1] = GetGValue(rgb);
	arr[2] = GetBValue(rgb);
	return util::toProfile(arr, key, app);
}


int util::toProfile(CListCtrl& lst, LPCTSTR key, LPCTSTR app)
{
	AcGeIntArray aw;
	CHeaderCtrl* pHeaderCtrl = lst.GetHeaderCtrl();
	int m = pHeaderCtrl->GetItemCount();
	aw.setLogicalLength(m);
	for (int i = 0; i < m; i++)
	{
		CRect rc;
		pHeaderCtrl->GetItemRect(i, &rc);
		aw[i] = rc.Width();
	}
	return util::toProfile(aw, key, app);
}
