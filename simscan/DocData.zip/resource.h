//{{NO_DEPENDENCIES}}
// ���������� ����, ��������� � Microsoft Visual C++.
// ������������ simscan.rc
//
#define IDS_PROJNAME                    100
#define IDD_DIALOG1                     102
#define IDD_DIALOG2                     104
#define IDC_EDIT1                       200
#define IDC_EDIT2                       201
#define IDC_EDIT3                       202
#define IDC_EDIT4                       203
#define IDC_EDIT5                       204
#define IDC_CHECK1                      205
#define IDC_BUTTON1                     206

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         207
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
