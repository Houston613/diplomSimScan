#pragma once

class CsimscanApp : public AcRxArxApp {

public:
	CsimscanApp() : AcRxArxApp() {}
	virtual AcRx::AppRetCode On_kInitAppMsg(void* pkt);
	virtual AcRx::AppRetCode On_kUnloadAppMsg(void* pkt);
	virtual void RegisterServerComponents();
	//r������
	static void Lytkin_slSim();
	static void Lytkin_slRab();
};
