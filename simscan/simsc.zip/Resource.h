//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by simscan.rc
//
#define IDS_PROJNAME 100

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         100
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
