#include "StdAfx.h"

#include "resource.h"
#include <dbSubD.h>
#include "util.h"
#include "simsc.h"

bool getPointScan(const AcGePoint3d& p, const AcGeVector3d& v, const AcDbObjectIdArray& ids, AcGePoint3d& ret)
{
    double dst = DBL_MAX;
    for (int i = 0; i < ids.length(); i++)
    {
        AcDbSubDMesh* mesh = nullptr;
        if (acdbOpenObject(mesh, ids[i], AcDb::kForRead) == Acad::eOk)
        {
            AcArray<AcDbSubentId> retSubents;
            AcArray<double> retIntersectDist;
            AcGePoint3dArray retIntersectPoint;
            if (mesh->computeRayIntersection(p, v, retSubents, retIntersectDist, retIntersectPoint) == Acad::eOk)
            {
                int imin = 0;
                for (int j = 1; j < retIntersectDist.length(); j++)
                    if (retIntersectDist[j] < retIntersectDist[imin]) imin = j;
                if (retIntersectDist[imin] < dst)
                {
                    dst = retIntersectDist[imin];
                    ret = retIntersectPoint[imin];
                }
            }
            mesh->close();
        }
    }
    return (dst != DBL_MAX);
}


void CsimscanApp::Lytkin_slSim()
{
    AcDbObjectIdArray ids;
    int n = util::GetMeshFromDb(ids);
    if (n == 0)
    {
        acutPrintf(_T("\n � ������� ��� �����..."));
        return;
    }
    AcDbObjectId trjId;
    if (!selectEntity<AcDbCurve>(L"\n������� ��������-���������� �������:", trjId))
    {
        acutPrintf(_T("\n �������� �������������..."));
        return;
    }
    double step = 0.01;
    double angl = 0.0001;
    AcGePoint3dArray pts;
    AcDbCurve* curve = nullptr;
    if (acdbOpenObject(curve, trjId, AcDb::kForRead) == Acad::eOk)
    {
        AcGePoint3d ep, p, ret;
        AcGeVector3d norm, vp, v;
        AcGeMatrix3d mat;
        double dist;
        curve->getEndPoint(ep);
        curve->getDistAtPoint(ep, dist);
        for (double cur = 0; cur < dist; cur += step)
        {
            curve->getPointAtDist(cur, p);
            curve->getFirstDeriv(p, norm);
            mat = AcGeMatrix3d::planeToWorld(norm);
            for (double a = 0.; a <= 6.28318530717959; a += angl)
            {
                v = mat * AcGeVector3d(cos(a), sin(a), 0.);
                if (getPointScan(p, v, ids, ret)) pts.append(ret);
            }
        }
        curve->close();
    }
    acutPrintf(_T("\n ������� %d �����..."), pts.length());
    for (int k = 0; k < pts.length(); k++)
    {
        //pts[k].x  ...  pts[k].y ... pts[k].z 
    }

}
